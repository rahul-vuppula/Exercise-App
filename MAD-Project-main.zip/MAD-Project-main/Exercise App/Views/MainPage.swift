//
//  MainPage.swift
//  Exercise App
//
//  Created by Bodi, Sai Abhinav on 10/21/23.
//

import UIKit

class MainPage: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
