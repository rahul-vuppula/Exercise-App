//
//  FavouritesVC.swift
//  Exercise App
//
//  Created by Bodi, Sai Abhinav on 10/26/23.
//

import UIKit
import CoreData

class FavouritesVC: UIViewController,UITableViewDelegate,UITableViewDataSource{

    
    
    var exercise:[FavoriteExercise]=[]
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let backgroundImage = UIImageView()
        backgroundImage.image = UIImage(named: "favorites.jpeg")
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 0.25

       
        view.addSubview(backgroundImage)

        
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false

        
        NSLayoutConstraint.activate([
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        fetchAndSortData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAndSortData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        exercise.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "exercise", for: indexPath) as! FavouritesTableCell
        
        cell.customLabel.text=exercise[indexPath.row].name
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        100
    }
    func fetchAndSortData() {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let managedContext = appDelegate.persistentContainer.viewContext
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            let fetchRequest: NSFetchRequest<FavoriteExercise> = FavoriteExercise.fetchRequest()
            let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
            fetchRequest.sortDescriptors = [sortDescriptor]
            do {
                exercise = try managedContext.fetch(fetchRequest)
                tableView.reloadData()
            } catch {
                print("Error fetching data: \(error.localizedDescription)")
            }
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "favoritesToDesc", let indexPath = tableView.indexPathForSelectedRow {
            let selectedData = exercise[indexPath.row]
            if let destinationVC = segue.destination as? ExerciseDescVC {
                destinationVC.name=selectedData.name!
                destinationVC.type=selectedData.type!
                destinationVC.equipment=selectedData.equipment!
                destinationVC.muscle=selectedData.muscle!
                destinationVC.instructions=selectedData.instructions!
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
