//
//  TrackingVC.swift
//  Exercise App
//
//  Created by  Santhosh Vemula on 10/22/23.
//

import UIKit

class TrackingVC: UIViewController {

    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var startBtn: UIButton!
    @IBOutlet weak var resetBtn: UIButton!
    @IBOutlet weak var caloriesBurnt: UILabel!
    @IBOutlet weak var previousCalories: UILabel!
    @IBOutlet weak var previousCaloriesburntBtn: UIButton!
    
    let userDefaults = UserDefaults.standard
    let START_TIME_KEY = "startTime"
    let STOP_TIME_KEY = "stopTime"
    let COUNTING_KEY = "countingkey"
    let PREVIOUS_DAY_CALORIES_KEY = "previousDayCalories"
    
    var scheduledTimer: Timer!
    var timerCounting:Bool = false
    var startTime:Date?
    var stopTime:Date?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let backgroundImageView = UIImageView(frame: view.bounds)
               backgroundImageView.contentMode = .scaleAspectFill
               backgroundImageView.clipsToBounds = true
               backgroundImageView.image = UIImage(named: "workout.jpg")
               view.addSubview(backgroundImageView)
               view.sendSubviewToBack(backgroundImageView)
        backgroundImageView.alpha = 0.25

        view.addSubview(backgroundImageView)

       
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        
        startTime = userDefaults.object(forKey: START_TIME_KEY) as? Date
        
        stopTime =  userDefaults.object(forKey: STOP_TIME_KEY) as? Date
        timerCounting =  userDefaults.bool(forKey: COUNTING_KEY)
        
        if timerCounting
        {
            startTimer()
        }
        else
        {
            stopTimer()
            if let start = startTime
            {
                if let stop = stopTime
                {
                    let time = calcRestartTime(start: start, stop: stop)
                    let diff = Date().timeIntervalSince(time)
                    setTimeLabel(Int(diff))
                }
            }
        }
    }
    
  
    @IBAction func startActionBtn(_ sender: Any) {
        if timerCounting {
            setstopTime(date: Date())
            stopTimer()
        } else {
            if let startTime = startTime {
                if let stopTime = stopTime {
                    let restartTime = calcRestartTime(start: startTime, stop: stopTime)
                    setstopTime(date: nil)
                    setstartTime(date: restartTime)
                } else {
                    setstartTime(date: Date())
                }
            } else {
                setstartTime(date: Date())
            }
            startTimer()
        }
    }
    
    func calcRestartTime(start: Date, stop: Date) -> Date
    {
        let diff = start.timeIntervalSince(stop)
        return Date().addingTimeInterval(diff)
    }
    func startTimer()
    {
        scheduledTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(refreshValue), userInfo: nil, repeats: true)
        setTimercounting(true)
        startBtn.setTitle("STOP", for: .normal)
        startBtn.setTitleColor(UIColor.red, for: .normal)
    }
    @objc func refreshValue()
    {
        if let start = startTime
        {
            let diff = Date().timeIntervalSince(start)
            setTimeLabel(Int(diff))
        }
        else
        {
            stopTimer()
            setTimeLabel(0)
        }
    }
    func setTimeLabel(_ val: Int)
    {
        let time = secondsToHoursMinutesSeconds(val)
        let timeString = makeTimeString(hour: time.0, min: time.1, sec: time.2)
        timerLabel.text = timeString
    }
    func secondsToHoursMinutesSeconds(_ ms: Int) -> (Int, Int, Int)
    {
        let hour = ms/3600
        let min = (ms % 3600) / 60
        let sec = (ms % 3600) % 60
        return (hour,min,sec)
    }
    
    func makeTimeString(hour: Int, min: Int, sec: Int) -> String
    {
        var timeString = ""
        timeString += String(format: "%02d", hour)
        timeString += ":"
        timeString += String(format: "%02d", min)
        timeString += ":"
        timeString += String(format: "%02d", sec)
        timeString += ""
        
        return timeString
    }
    
    func stopTimer()
    {
        if scheduledTimer != nil
        {
            scheduledTimer.invalidate()
        }
        setTimercounting(false)
        startBtn.setTitle("START", for: .normal)
        startBtn.setTitleColor(UIColor.systemGreen, for: .normal)
    }
    
    @IBAction func resetActionBtn(_ sender: Any) {
        saveCalories(0)
        caloriesBurnt.text = "0 calories burnt"
            
        setstopTime(date: nil)
        setstartTime(date: nil)
        timerLabel.text = makeTimeString(hour: 0, min: 0, sec: 0)
        stopTimer()
    }
    
    func setstartTime(date: Date?)
    {
        startTime = date
        userDefaults.set(startTime,forKey: START_TIME_KEY)
    }
    func setstopTime(date: Date?)
    {
        stopTime = date
        userDefaults.set(stopTime,forKey: STOP_TIME_KEY)
    }
    func setTimercounting(_ val:Bool)
    {
        timerCounting = val
        userDefaults.set(timerCounting,forKey: COUNTING_KEY)
    }
    func saveCalories(_ calories: Int) {
        UserDefaults.standard.set(calories, forKey: "Calories")
    }

    func retrieveCalories() -> Int {
        return UserDefaults.standard.integer(forKey: "Calories")
    }
    
    @IBAction func CalCalories(_ sender: Any) {
        if let timeString = timerLabel.text {
            let components = timeString.components(separatedBy: ":")
            
            if components.count == 3,
               let hours = Int(components[0]),
               let minutes = Int(components[1]),
               let seconds = Int(components[2]) {
                
                let totalTimeInSeconds = hours * 3600 + minutes * 60 + seconds
                
                let caloriesBurn = totalTimeInSeconds * 10
                
                caloriesBurnt.text = "\(caloriesBurn) calories burnt"
                userDefaults.set(caloriesBurn, forKey: PREVIOUS_DAY_CALORIES_KEY)
            }
        }
    }
    
    @IBAction func prevCalories(_ sender: Any) {
        let previousDayCalories = userDefaults.integer(forKey: PREVIOUS_DAY_CALORIES_KEY)
        previousCalories.text = "Previous Day's Calories: \(previousDayCalories)"
        
    }
}
