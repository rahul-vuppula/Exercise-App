//
//  ExerciseListVC.swift
//  Exercise App
//
//  Created by rahul vuppula on 10/22/23.
//

import UIKit

class ExerciseListVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, UISearchResultsUpdating {
    
    var selectedType=""
    var selectedMuscle=""
    var selectedDifficulty=""
    var filterdData=[] as [ToDO]
    var data=[ToDO]()
    let searchController = UISearchController()
    @IBOutlet weak var selectedExerciseTable: UITableView!
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        fetchExercise()
        initSearchController()
        let backgroundImage = UIImageView()
        backgroundImage.image = UIImage(named: "workout2.jpeg")
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 0.25

        
        view.addSubview(backgroundImage)

        
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false

        
        NSLayoutConstraint.activate([
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    
    func fetchExercise(){
        //let muscle = "biceps".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        //   let url = URL(string: "https://api.api-ninjas.com/v1/exercises?muscle=" + muscle!)!
        let url = URL(string: "https://api.api-ninjas.com/v1/exercises?muscle="+self.selectedMuscle)!
        var request = URLRequest(url: url)
        request.setValue("PFasmpn3uopZmV30O3h1SQ==iHOFxQiwfMjgu37f", forHTTPHeaderField: "X-Api-Key")
        
        let task = URLSession.shared.dataTask(with: request) { [weak self] (data, response, error) in
            guard let data = data, error == nil else { return }
            
            do {
                if String(data: data, encoding: .utf8) != nil {
                  
                    //print(jsonString)
                    
                    
                    let exercises = try JSONDecoder().decode([ToDO].self, from: data)
                    //print(exercises)
                    self?.data=exercises
                } else {
                    print("Error converting JSON data to string.")
                }
                
                
                DispatchQueue.main.async {
                    self?.selectedExerciseTable.reloadData()
                }
            } catch {
                print("Error decoding data: \(error.localizedDescription)")
            }
        }
        
        task.resume()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(searchController.isActive){
            return filterdData.count
        }
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "DetailedExerciseCell", for: indexPath) as! DetailedExerciseCell
        if(searchController.isActive){
            cell.customLabel.text=filterdData[indexPath.row].name
            return cell
        }
        else{
            cell.customLabel.text=data[indexPath.row].name
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        100
    }
    
    
    func initSearchController(){
        searchController.loadViewIfNeeded()
        searchController.searchResultsUpdater=self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.enablesReturnKeyAutomatically = false
        searchController.searchBar.returnKeyType = UIReturnKeyType.done
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        searchController.searchBar.scopeButtonTitles = ["All","beginner","intermediate","expert"]
        searchController.scopeBarActivation = .onSearchActivation
        searchController.searchBar.delegate = self
        
    }
    
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        let scopeButton = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
        let searchText = searchBar.text!
        filterForSearchTextandScopeBtn(searchText: searchText, scopeButton: scopeButton)
        //filterForSearchTextandScopeBtn(searchText: searchText)
    }
    
    
    func filterForSearchTextandScopeBtn(searchText: String, scopeButton: String = "All"){
        filterdData=data.filter
        {
            shape in
            //let error = "Error"
            let scopeMatch=(scopeButton == "All" || shape.difficulty == scopeButton)
            if(searchController.searchBar.text != "")
            {
                let searchTextMatch = shape.name.lowercased().contains(searchText.lowercased())
                return searchTextMatch && scopeMatch
                //return searchTextMatch
            }
            else{
                return scopeMatch
            }
        }
        selectedExerciseTable.reloadData()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ListToDetail", let indexPath = tableView.indexPathForSelectedRow {
            let selectedData = data[indexPath.row]
            if let destinationVC = segue.destination as? ExerciseDescVC {
                destinationVC.name=selectedData.name
                destinationVC.type=selectedData.type
                destinationVC.equipment=selectedData.equipment
                destinationVC.muscle=selectedData.muscle
                destinationVC.instructions=selectedData.instructions
            }
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
