//
//  ExerciseDescVC.swift
//  Exercise App
//
//  Created by BALREDDY GOVINDUGARI on 10/22/23.
//

import UIKit
import CoreData
import WebKit
class ExerciseDescVC: UIViewController {
    var isFavorite = false
    let videoIDs: [String: String] = ["Rickshaw Carry": "oytPQLjG84k",
                                      "Palms-down wrist curl over bench":"jtQslxR3f0A",
                                      "Straight-bar wrist roll-up":"-lOFG0U_rlY",
                                      "Dumbbell front raise to lateral raise":"SqTLytmDy_8",
                                      "Clean and press":"MsOSMJ33CNA",
                                      "Single-arm palm-in dumbbell shoulder press":"9cqpRlSNi6I",
                                      "Clean and jerk":"PjY1rH4_MOA",
                                      "Single-arm kettlebell push-press":"Ln9xtKNuSFY",
                                      "Military press":"43GSKivZnw4",
                                      "Standing palms-in shoulder press":"DSb78U21bb8",
                                      "Seated barbell shoulder press":"43GSKivZnw4",
                                      "Seated Dumbbell Press":"poD_-zaG9hk",
                                      "Standing dumbbell shoulder press":"B-aVuyhvLHU",
                                      "Barbell glute bridge":"DQv1IMQDbE4",
                                      "Barbell Hip Thrust":"aweBS7K71l8",
                                      "Single-leg cable hip extension":"f3ebTCWwOwg",
                                      "Glute bridge":"Q_Bpj91Yiis",
                                      "Single-leg glute bridge":"b1zTCyGJXCQ",
                                      "Step-up with knee raise":"oEgiI2-iUJo",
                                      "Kettlebell thruster":"ktDIi7qBHHM",
                                      "Kneeling Squat":"GBH5KnZi6xQ",
                                      "Flutter Kicks":"ZB1SwBRVLCc",
                                      "Glute Kickback":"ifP5sFBT7IE",
                                      "Hip Circles (Prone)":"c9qsW_OnpTc",
                                      "Standing Hip Circles":"yFi1FDOFXq0",
                                      "Clam":"iNX2NUWhfIo",
                                      "Illiotbial band SMR":"asigNf1sh-k",
                                      "Thigh abductor":"CjAVezAggkI",
                                      "Fire Hydrant":"hjMEwbXhya4",
                                      "Windmills":"64uzFS_eyK4",
                                      "Monster Walk":"dgbhiejP7oI",
                                      "IT Band and Glute Stretch":"y27HAM7CeBw",
                                      "Single-leg lying cross-over stretch":"YOaK6WMzqBY",
                                      "Single-Leg Press":"sxF9BcDt-yY",
                                      "Clean from Blocks":"T4EAdzwVEg4",
                                      "Barbell Full Squat":"kRX2NfqM90g",
                                      "Tire flip":"aIDjGG_xwHg",
                                      "Barbell back squat to box":"nBc_2Jyp3tM",
                                      "Push-press":"ep30avTSMB0",
                                      "Power snatch-":"TL8SMp7RdXQ",
                                      "Hang Clean":"DaKC_BEN5bk",
                                      "Reverse Band Box Squat":"Dh0V-hfztb0",
                                      "Jumping rope":"6h_q6ixtuYM"]

    var name=""
    var type=""
    var muscle=""
    var equipment=""
    var difficulty=""
    var instructions=""
    @IBOutlet weak var web: WKWebView!
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var instructionsTextView: UITextView!
    @IBOutlet weak var labelEquipment: UILabel!
    @IBOutlet weak var equipmentTextView: UITextView!
    @IBOutlet weak var uiImage: UIImageView!
    override func viewDidLoad() {
        let backgroundImage = UIImageView()
        backgroundImage.image = UIImage(named: "Desc.png")
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 0.25

       
        view.addSubview(backgroundImage)

        
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false

        
        NSLayoutConstraint.activate([
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
         let instructions = self.instructions
        self.instructionsTextView.text = instructions.capitalized
         self.equipmentTextView.text = self.equipment

         
         let favoriteButton = UIBarButtonItem(image: UIImage(systemName: "heart"), style: .plain, target: self, action: #selector(favoriteButtonTapped))

         
         navigationItem.rightBarButtonItem = favoriteButton

         
         isFavorite = isExerciseInFavorites()

         
         updateFavoriteButtonImage()
        
        //video
        //print(videoIDs["Rickshaw Carry"])
        //
        video(id: videoIDs[self.name] ?? "oytPQLjG84k")
        //video(id: videoIDs[self.name] ?? "Ln9xtKNuSFY")
    }
    
    
    func video(id:String){
        if let youtubeURL = URL(string: "https://www.youtube.com/embed/\(id)") {
            let request = URLRequest(url: youtubeURL)
            web.load(request)
        }
    }
    
    func isExerciseInFavorites() -> Bool {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return false
            }

            let context = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "FavoriteExercise")
            fetchRequest.predicate = NSPredicate(format: "name == %@", self.name)

            do {
                let count = try context.count(for: fetchRequest)
                return count > 0
            } catch {
                print("Error checking if exercise is in favorites: \(error.localizedDescription)")
                return false
            }
        }

        @objc func favoriteButtonTapped() {
            
            isFavorite.toggle()

            
            updateFavoriteButtonImage()

            
            if isFavorite {
                addToFavorites()
            } else {
                deleteFromFavorites()
            }
        }

        func updateFavoriteButtonImage() {
            let imageName = isFavorite ? "heart.fill" : "heart"
            navigationItem.rightBarButtonItem?.image = UIImage(systemName: imageName)
        }

        func addToFavorites() {
            
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }

            let context = appDelegate.persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "FavoriteExercise", in: context)!

            let favoriteExercise = NSManagedObject(entity: entity, insertInto: context)
            favoriteExercise.setValue(self.name, forKey: "name")
            favoriteExercise.setValue(self.type, forKey: "type")
            favoriteExercise.setValue(self.muscle, forKey: "muscle")
            favoriteExercise.setValue(self.equipment, forKey: "equipment")
            favoriteExercise.setValue(self.difficulty, forKey: "difficulty")
            favoriteExercise.setValue(self.instructions, forKey: "instructions")

            do {
                try context.save()
                print("Data added to favorites.")
            } catch {
                print("Error adding data to favorites: \(error.localizedDescription)")
            }

            
            updateFavoriteButtonImage()
        }

        func deleteFromFavorites() {
            
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }

            let context = appDelegate.persistentContainer.viewContext

            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "FavoriteExercise")
            fetchRequest.predicate = NSPredicate(format: "name == %@", self.name)

            do {
                let objects = try context.fetch(fetchRequest)
                for object in objects {
                    context.delete(object as! NSManagedObject)
                }

                try context.save()
                print("Data deleted from favorites.")
            } catch {
                print("Error deleting data from favorites: \(error.localizedDescription)")
            }

            
            updateFavoriteButtonImage()
        }

}
