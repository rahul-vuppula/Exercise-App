//
//  MainPageVC.swift
//  Exercise App
//
//  Created by Bodi, Sai Abhinav on 10/22/23.
//

import UIKit


class MainPageVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var data=[ToDO]()
    var type = ""
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchingData()
        let font = UIFont.boldSystemFont(ofSize: 14)
                segmentedControl.setTitleTextAttributes([NSAttributedString.Key.font: font], for: .normal)

               
                let selectedFont = UIFont.boldSystemFont(ofSize: 14)
                segmentedControl.setTitleTextAttributes([NSAttributedString.Key.font: selectedFont], for: .selected)
        
        let backgroundImage = UIImageView()
        backgroundImage.image = UIImage(named: "workout.jpg")
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 0.25

        
        view.addSubview(backgroundImage)

        
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false

        
        NSLayoutConstraint.activate([
            backgroundImage.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundImage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundImage.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            backgroundImage.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    
    }
    
    @IBAction func exerciseSegment(_ sender: Any) {
    }
    
    @IBOutlet weak var exerciseList: UITableView!
    
    
    @IBAction func segmentedValueChanged(_ sender: UISegmentedControl) {
        updateTableView()
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "ExerciseCategory", for: indexPath) as! ExerciceCategoryCell
        cell.customLabel.text=data[indexPath.row].muscle.capitalized
        return cell
    }
    
    func fetchingData(){
        //let type = self.type.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let originalUrl="https://api.api-ninjas.com/v1/exercises?type=\(self.type)"
        let url = URL(string: originalUrl)!
        //print(originalUrl)
        var request = URLRequest(url: url)
        request.setValue("PFasmpn3uopZmV30O3h1SQ==iHOFxQiwfMjgu37f", forHTTPHeaderField: "X-Api-Key")
        
        let task = URLSession.shared.dataTask(with: request) { [weak self] (data, response, error) in
            guard let data = data, error == nil else { return }
            do {
                if let jsonString = String(data: data, encoding: .utf8) {
                    
                    //print(jsonString)
                    
                    
                    let exercises = try JSONDecoder().decode([ToDO].self, from: data)
                   //print(exercises)
                    self?.data=exercises
                } else {
                    print("Error converting JSON data to string.")
                }
                
                    DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            } catch {
                print("Error decoding data: \(error.localizedDescription)")
            }
        }
        
        //  task.resume()
        /*var request = URLRequest(url: url)
         request.setValue("PFasmpn3uopZmV30O3h1SQ==iHOFxQiwfMjgu37f", forHTTPHeaderField: "X-Api-Key")
         let session=URLSession.shared
         let task=session.dataTask(with: request) {(data, response, error) in
         guard let data = data else { return }
         //let parsingData = try JSONDecoder.decode([ToDo].self,from:data)
         //completion(parsingData)
         }
         var request = URLRequest(url: url)
         request.setValue("PFasmpn3uopZmV30O3h1SQ==iHOFxQiwfMjgu37f", forHTTPHeaderField: "X-Api-Key")
         let task = URLSession.shared.dataTask(with: request) {(data, response, error) in
         do{
         let data = data
         }catch{
         print("PArsing error")
         }
         //guard let data = data else { return }
         //print(String(data: data!, encoding: .utf8)!)
         }
         let dataTask = session.dataTask(with: url!){ data,response,error in
         if data!=nil && error==nil{
         do{
         let parsingData = try JSONDecoder().decode([ToDO].self, from: data!)
         completion(parsingData)
         }catch{
         print("PArsing error")
         }
         }
         }*/
        task.resume()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func updateTableView() {
        // Get the selected segment index
        let selectedIndex = segmentedControl.selectedSegmentIndex

        // Update your data source based on the selected segment (modify this according to your data structure)
        // Example:
        switch selectedIndex {
        case 0:
            self.type="strength"
            print(self.type)
        case 1:
            self.type="powerlifting"
            print(self.type)
        case 2:
            self.type="stretching"
            print(self.type)
        case 3:
            self.type="cardio"
            print(self.type)
        default:
            break
        }

        // Reload the table view to reflect the changes
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.fetchingData()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "CategoryToList", let indexPath = tableView.indexPathForSelectedRow {
            let selectedData = data[indexPath.row]
            if let destinationVC = segue.destination as? ExerciseListVC {
                destinationVC.selectedType = selectedData.type
                destinationVC.selectedMuscle=selectedData.muscle
                destinationVC.selectedDifficulty=selectedData.difficulty
            }
        }
    }

    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
