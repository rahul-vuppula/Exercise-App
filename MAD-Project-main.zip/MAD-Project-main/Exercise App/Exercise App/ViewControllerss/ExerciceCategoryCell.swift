//
//  ExerciceCategoryCell.swift
//  Exercise App
//
//  Created by Bodi, Sai Abhinav on 11/8/23.
//

import UIKit

class ExerciceCategoryCell: UITableViewCell {

    @IBOutlet weak var customLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       
        //customLabel.textAlignment = .justified
        customLabel.textColor = .black
        customLabel.font = UIFont.boldSystemFont(ofSize: 16)
        //customLabel.backgroundColor = UIColor.gray.withAlphaComponent(0.1)
        customLabel.layer.cornerRadius = 8
        customLabel.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }


        override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
            super.init(style: style, reuseIdentifier: reuseIdentifier)

            
            contentView.addSubview(customLabel)

            customLabel.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                customLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
                customLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
                customLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
                customLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16)
            ])
        }

        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            // Implement this method if needed, but it's usually not necessary for custom table view cells
        }

}
